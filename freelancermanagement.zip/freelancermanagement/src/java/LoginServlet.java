import com.yourproject.models.User;
import com.yourproject.utils.DBConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final String ERROR_PAGE = "error.html";
    private static final String LOGIN_ERROR_PAGE = "login_error.html";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try (Connection connection = DBConnection.getConnection()) {
            if (connection == null) {
                response.sendRedirect(ERROR_PAGE);
                return;
            }

            // SQL query to fetch user details
            String loginSQL = "SELECT user_id, username, role FROM users WHERE username = ? AND password = ?";
            try (PreparedStatement ps = connection.prepareStatement(loginSQL)) {
                ps.setString(1, username);
                ps.setString(2, password);

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        User user = new User();
                        user.setId(rs.getInt("user_id"));
                        user.setUsername(rs.getString("username"));
                        user.setRole(rs.getString("role"));

                        // After user successfully logs in
                        HttpSession session = request.getSession();
                        session.setAttribute("userId", user.getId());
                        session.setAttribute("currentUser", user);
                        session.setAttribute("role", user.getRole().toLowerCase());  // Add this line

                        String role = user.getRole().toLowerCase();
                        System.out.println("User role retrieved: " + role);

                        // Role-based redirection with additional ID fetching for client and freelancer roles
                        switch (role) {
                            case "freelancer":
                                String freelancerSQL = "SELECT freelancer_id FROM freelancers WHERE user_id = ?";
                                try (PreparedStatement freelancerPs = connection.prepareStatement(freelancerSQL)) {
                                    freelancerPs.setInt(1, user.getId());
                                    try (ResultSet freelancerRs = freelancerPs.executeQuery()) {
                                        if (freelancerRs.next()) {
                                            session.setAttribute("freelancerId", freelancerRs.getInt("freelancer_id"));
                                            System.out.println("Freelancer ID set in session: " + freelancerRs.getInt("freelancer_id"));
                                        }
                                    }
                                }
                                response.sendRedirect("freelancer_dashboard.jsp");
                                break;

                            case "client":
                                String clientSQL = "SELECT client_id FROM clients WHERE user_id = ?";
                                try (PreparedStatement clientPs = connection.prepareStatement(clientSQL)) {
                                    clientPs.setInt(1, user.getId());
                                    try (ResultSet clientRs = clientPs.executeQuery()) {
                                        if (clientRs.next()) {
                                            session.setAttribute("clientId", clientRs.getInt("client_id"));
                                        }
                                    }
                                }
                                response.sendRedirect("userDashboard.jsp");
                                break;

                            case "admin":
                                response.sendRedirect("admin_dashboard.jsp");
                                break;

                            default:
                                response.sendRedirect(LOGIN_ERROR_PAGE);
                                break;
                        }

                    } else {
                        response.sendRedirect(LOGIN_ERROR_PAGE);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect(ERROR_PAGE);
        }
    }
}
