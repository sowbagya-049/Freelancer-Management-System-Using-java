// ProjectServlet.java
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.yourproject.utils.DBConnection;

@WebServlet("/project")
public class ProjectServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try (Connection conn = DBConnection.getConnection()) {
            if ("add".equals(action)) {
                addProject(conn, request);
            } else if ("edit".equals(action)) {
                editProject(conn, request);
            } else if ("delete".equals(action)) {
                deleteProject(conn, request);
            }

            response.sendRedirect("project_list.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addProject(Connection conn, HttpServletRequest request) throws SQLException {
        String projectName = request.getParameter("project_name");
        String description = request.getParameter("description");
        String budget = request.getParameter("budget");
        String deadline = request.getParameter("deadline");
        int freelancerId = Integer.parseInt(request.getParameter("freelancer_id"));

        String sql = "INSERT INTO projects (client_id, project_name, description, budget, deadline, status, freelancer_id) "
                   + "VALUES (?, ?, ?, ?, ?, 'open', ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, freelancerId); // Assume client_id is the same as freelancer_id
            stmt.setString(2, projectName);
            stmt.setString(3, description);
            stmt.setBigDecimal(4, new java.math.BigDecimal(budget));
            stmt.setDate(5, java.sql.Date.valueOf(deadline));
            stmt.setInt(6, freelancerId);
            stmt.executeUpdate();
        }
    }

    private void editProject(Connection conn, HttpServletRequest request) throws SQLException {
        int projectId = Integer.parseInt(request.getParameter("project_id"));
        String projectName = request.getParameter("project_name");
        String description = request.getParameter("description");
        String budget = request.getParameter("budget");
        String deadline = request.getParameter("deadline");

        String sql = "UPDATE projects SET project_name = ?, description = ?, budget = ?, deadline = ? WHERE project_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, projectName);
            stmt.setString(2, description);
            stmt.setBigDecimal(3, new java.math.BigDecimal(budget));
            stmt.setDate(4, java.sql.Date.valueOf(deadline));
            stmt.setInt(5, projectId);
            stmt.executeUpdate();
        }
    }

    private void deleteProject(Connection conn, HttpServletRequest request) throws SQLException {
        int projectId = Integer.parseInt(request.getParameter("project_id"));

        String sql = "DELETE FROM projects WHERE project_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, projectId);
            stmt.executeUpdate();
        }
    }
}
