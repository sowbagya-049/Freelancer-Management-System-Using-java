import com.sun.jdi.connect.spi.Connection;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServlet;

import javax.servlet.annotation.WebServlet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/getPurchases")
public class PurchasesServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer freelancerId = (Integer) session.getAttribute("freelancer_id"); // Assuming freelancer ID is stored in session

        List<Purchase> purchases = new ArrayList<>();
        
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/freelancer_sys", "root", "Sow@2005#18")) {
            String sql = "SELECT c.client_name, p.project_name, s.sale_date, s.amount " +
                         "FROM sales s " +
                         "JOIN projects p ON s.project_id = p.project_id " +
                         "JOIN clients c ON s.client_id = c.client_id " +
                         "WHERE s.freelancer_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, freelancerId);
                ResultSet rs = pstmt.executeQuery();
                
                while (rs.next()) {
                    Purchase purchase = new Purchase();
                    purchase.setClientName(rs.getString("client_name"));
                    purchase.setProjectName(rs.getString("project_name"));
                    purchase.setPurchaseDate(rs.getTimestamp("sale_date")); // Timestamp for sale_date
                    purchase.setAmount(rs.getDouble("amount"));
                    purchases.add(purchase);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        request.setAttribute("purchases", purchases);
        request.getRequestDispatcher("purchase.jsp").forward(request, response);
    }
    
    // Purchase class to hold purchase details
    public static class Purchase {
        private String clientName;
        private String projectName;
        private java.util.Date purchaseDate; // Use java.util.Date for better handling
        private double amount;

        // Getters and Setters
        public String getClientName() { return clientName; }
        public void setClientName(String clientName) { this.clientName = clientName; }
        public String getProjectName() { return projectName; }
        public void setProjectName(String projectName) { this.projectName = projectName; }
        public java.util.Date getPurchaseDate() { return purchaseDate; }
        public void setPurchaseDate(java.util.Date purchaseDate) { this.purchaseDate = purchaseDate; }
        public double getAmount() { return amount; }
        public void setAmount(double amount) { this.amount = amount; }
    }
}
