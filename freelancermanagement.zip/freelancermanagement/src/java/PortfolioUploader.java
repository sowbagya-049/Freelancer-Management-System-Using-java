import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Map;
import java.util.HashMap;
import javax.servlet.http.Part;

public abstract class PortfolioUploader implements DatabaseConfig {

    private static final String UPLOAD_DIRECTORY = "C:/uploads/";

    // Method to save uploaded file
    protected String saveFile(Part filePart) throws IOException {
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        String savePath = UPLOAD_DIRECTORY + fileName;
        filePart.write(savePath);
        return savePath;
    }

    // Method to retrieve freelancer ID from session attributes stored in a Map
    protected Integer getFreelancerId(HttpSession session) {
        Map<String, Object> sessionAttributes = new HashMap<>();
        sessionAttributes.put("freelancer_id", session.getAttribute("freelancer_id"));
        return (Integer) sessionAttributes.get("freelancer_id");
    }

    // Method to send response to client
    protected void sendResponse(HttpServletResponse response, String message) throws IOException {
        response.getWriter().println("<h2>" + message + "</h2>");
    }

    // Abstract method to connect and save portfolio data
    protected abstract void savePortfolioData(int freelancerId, String projectId, String title,
                                              String filePath, String description, String skills,
                                              HttpServletResponse response) throws IOException;
}
