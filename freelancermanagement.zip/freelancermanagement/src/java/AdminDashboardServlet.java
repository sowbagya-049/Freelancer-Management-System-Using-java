import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AdminDashboardServlet")
public class AdminDashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/freelancer_sys", "root", "Sow@2005#18");
            Statement stmt = conn.createStatement();

            // Query to get projects
            String projectsQuery = "SELECT p.project_name AS title, f.user_id AS freelancer, c.user_id AS user, p.status "
                                 + "FROM projects p "
                                 + "JOIN clients c ON p.client_id = c.client_id "
                                 + "JOIN freelancers f ON p.freelancer_id = f.user_id";
            ResultSet projectsResultSet = stmt.executeQuery(projectsQuery);

            out.print("{\"projects\":[");
            boolean firstProject = true;
            while (projectsResultSet.next()) {
                if (!firstProject) {
                    out.print(",");
                }
                out.print("{");
                out.print("\"title\":\"" + projectsResultSet.getString("title") + "\",");
                out.print("\"freelancer\":\"" + projectsResultSet.getString("freelancer") + "\",");
                out.print("\"user\":\"" + projectsResultSet.getString("user") + "\",");
                out.print("\"status\":\"" + projectsResultSet.getString("status") + "\"");
                out.print("}");
                firstProject = false;
            }
            out.print("],");

            // Query to get freelancers
            String freelancersQuery = "SELECT user_id, name FROM freelancers";
            ResultSet freelancersResultSet = stmt.executeQuery(freelancersQuery);

            out.print("\"freelancers\":[");
            boolean firstFreelancer = true;
            while (freelancersResultSet.next()) {
                if (!firstFreelancer) {
                    out.print(",");
                }
                out.print("{");
                out.print("\"user_id\":\"" + freelancersResultSet.getString("user_id") + "\",");
                out.print("\"name\":\"" + freelancersResultSet.getString("name") + "\"");
                out.print("}");
                firstFreelancer = false;
            }
            out.print("],");

            // Query to get clients (users)
            String usersQuery = "SELECT user_id, name FROM clients";
            ResultSet usersResultSet = stmt.executeQuery(usersQuery);

            out.print("\"users\":[");
            boolean firstUser = true;
            while (usersResultSet.next()) {
                if (!firstUser) {
                    out.print(",");
                }
                out.print("{");
                out.print("\"user_id\":\"" + usersResultSet.getString("user_id") + "\",");
                out.print("\"name\":\"" + usersResultSet.getString("name") + "\"");
                out.print("}");
                firstUser = false;
            }
            out.print("]}");

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"error\":\"An error occurred\"}");
        } finally {
            out.close();
        }
    }
}