import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PurchaseProjectServlet")
public class PurchaseProjectServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/freelancer_sys"; // Replace with your DB details
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Sow@2005#18";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int projectId = Integer.parseInt(request.getParameter("project_id"));
        int clientId = Integer.parseInt(request.getParameter("client_id"));
        int freelancerId = Integer.parseInt(request.getParameter("freelancer_id"));
        BigDecimal amount = new BigDecimal(request.getParameter("amount"));

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String insertQuery = "INSERT INTO purchases (project_id, client_id, freelancer_id, amount, sale_date) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)";
            PreparedStatement stmt = conn.prepareStatement(insertQuery);
            stmt.setInt(1, projectId);
            stmt.setInt(2, clientId);
            stmt.setInt(3, freelancerId);
            stmt.setBigDecimal(4, amount);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Redirect to the JSP page to view updated purchases
        response.sendRedirect("purchasedProjects.jsp");
    }
}
