import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/upload_handler")
@MultipartConfig
public class UploadHandlerServlet extends PortfolioUploader {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Integer freelancerId = getFreelancerId(session);

        if (freelancerId == null) {
            sendResponse(response, "Error: Freelancer ID not found. Please log in again.");
            return;
        }

        Part filePart = request.getPart("portfolio_file");
        if (filePart == null || filePart.getSize() == 0) {
            sendResponse(response, "Error: No file uploaded.");
            return;
        }

        // Save file and other form data
        String filePath = saveFile(filePart);
        String projectId = request.getParameter("project_id");
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String skills = request.getParameter("skills");

        // Save portfolio data to database
        savePortfolioData(freelancerId, projectId, title, filePath, description, skills, response);
    }

    @Override
    protected void savePortfolioData(int freelancerId, String projectId, String title,
                                     String filePath, String description, String skills,
                                     HttpServletResponse response) throws IOException {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "INSERT INTO portfolio (freelancer_id, project_id, title, file_path, description, skills) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, freelancerId);
                pstmt.setInt(2, Integer.parseInt(projectId));
                pstmt.setString(3, title);
                pstmt.setString(4, filePath);
                pstmt.setString(5, description);
                pstmt.setString(6, skills);

                int row = pstmt.executeUpdate();
                if (row > 0) {
                    sendResponse(response, "Portfolio uploaded successfully!");
                } else {
                    sendResponse(response, "Error: Failed to upload portfolio.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            sendResponse(response, "Error: " + e.getMessage());
        }
    }
}
