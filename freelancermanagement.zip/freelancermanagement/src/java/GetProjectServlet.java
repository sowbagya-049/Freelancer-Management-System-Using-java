import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/GetProjectServlet")
public class GetProjectServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int projectId = Integer.parseInt(request.getParameter("project_id"));
        int clientId = Integer.parseInt(request.getParameter("client_id"));
        int freelancerId = Integer.parseInt(request.getParameter("freelancer_id"));
        double amount = Double.parseDouble(request.getParameter("amount"));

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/freelancer_sys", "root", "Sow@2005#18");

            // Check if freelancer_id exists in freelancers table
            String checkFreelancerSql = "SELECT freelancer_id FROM freelancers WHERE freelancer_id = ?";
            pstmt = conn.prepareStatement(checkFreelancerSql);
            pstmt.setInt(1, freelancerId);
            ResultSet rs = pstmt.executeQuery();

            Integer actualFreelancerId = rs.next() ? freelancerId : null; // If not found, set to null

            // Insert into sales with NULL freelancer_id if not found
            String sql = "INSERT INTO sales (project_id, client_id, freelancer_id, amount) VALUES (?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, projectId);
            pstmt.setInt(2, clientId);
            if (actualFreelancerId != null) {
                pstmt.setInt(3, actualFreelancerId);
            } else {
                pstmt.setNull(3, java.sql.Types.INTEGER);
            }
            pstmt.setDouble(4, amount);
            pstmt.executeUpdate();
            response.getWriter().write("Project purchased successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}
