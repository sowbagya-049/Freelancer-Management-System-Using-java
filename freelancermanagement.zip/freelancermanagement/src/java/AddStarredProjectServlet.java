import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/AddStarredProjectServlet")
public class AddStarredProjectServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String projectId = request.getParameter("project_id");
        String clientId = request.getParameter("client_id");
        String freelancerId = request.getParameter("freelancer_id");
        String projectName = request.getParameter("project_name");

        // JDBC connection details
        String jdbcURL = "jdbc:mysql://localhost:3306/freelancer_sys";
        String dbUser = "root";  // Change to your DB username
        String dbPassword = "Sow@2005#18";  // Change to your DB password

        try (Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
            String sql = "INSERT INTO starred_projects (project_id, client_id, freelancer_id, project_name) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, Integer.parseInt(projectId));
            statement.setObject(2, clientId != null && !clientId.isEmpty() ? Integer.parseInt(clientId) : null);
            statement.setInt(3, Integer.parseInt(freelancerId));
            statement.setString(4, projectName);
            statement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to add starred project.");
            return;
        }

        response.sendRedirect("starproject.jsp");
    }
}