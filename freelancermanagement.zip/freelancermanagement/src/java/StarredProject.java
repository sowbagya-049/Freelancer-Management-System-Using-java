package com.example.model;

public class StarredProject {
    private int starredProjectId;
    private int projectId;
    private int freelancerId;
    private String projectName;
    private String clientCompany;

    // Getters and setters
    public int getStarredProjectId() { return starredProjectId; }
    public void setStarredProjectId(int starredProjectId) { this.starredProjectId = starredProjectId; }

    public int getProjectId() { return projectId; }
    public void setProjectId(int projectId) { this.projectId = projectId; }

    public int getFreelancerId() { return freelancerId; }
    public void setFreelancerId(int freelancerId) { this.freelancerId = freelancerId; }

    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }

    public String getClientCompany() { return clientCompany; }
    public void setClientCompany(String clientCompany) { this.clientCompany = clientCompany; }
}
