import com.yourproject.utils.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/RemoveStarredProjectServlet")
public class RemoveStarredProjectServlet extends HttpServlet {
    private static final String DELETE_STARRED_PROJECT_SQL = "DELETE FROM starred_projects WHERE project_id = ? AND client_id = ?";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Get the project ID and client ID from the session
        Integer projectId = Integer.parseInt(request.getParameter("projectId"));
        Integer clientId = (Integer) request.getSession().getAttribute("clientId");

        // Establish database connection
        try (Connection conn = DBConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement pstmt = conn.prepareStatement(DELETE_STARRED_PROJECT_SQL)) {
                    pstmt.setInt(1, projectId);
                    pstmt.setInt(2, clientId);
                    pstmt.executeUpdate();
                    // Redirect back to the starred projects page after removal
                    response.sendRedirect("ViewStarredProject.jsp");
                }
            } else {
                response.sendRedirect("error.html");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.html");
        }
    }
}
