import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SignupServlet")
public class SignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/freelancer_sys?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "root"; 
    private static final String DB_PASSWORD = "Sow@2005#18"; 

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Load MySQL JDBC Driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            displayError(response, "JDBC Driver not found: " + e.getMessage());
            return;
        }

        // Collect form data
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        String username = request.getParameter("username"); // Collect username

        // Validate mandatory fields
        if (email == null || password == null || role == null || username == null) {
            displayError(response, "All fields are required.");
            return;
        }

        String userSql = "INSERT INTO users (email, password, role, username) VALUES (?, ?, ?, ?)";
        String clientSql = "INSERT INTO clients (user_id, company_name, contact_info) VALUES (?, ?, ?)";
        String freelancerSql = "INSERT INTO freelancers (user_id, skills, experience, portfolio) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // Insert user into users table
            try (PreparedStatement userStmt = conn.prepareStatement(userSql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                userStmt.setString(1, email);
                userStmt.setString(2, password);
                userStmt.setString(3, role);
                userStmt.setString(4, username); // Set the username

                // Execute user insert
                if (userStmt.executeUpdate() > 0) {
                    // Get the generated user ID
                    try (ResultSet generatedKeys = userStmt.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            int userId = generatedKeys.getInt(1); // Get the generated user ID

                            // Now insert into the appropriate table based on the role
                            if ("client".equalsIgnoreCase(role)) {
                                String companyName = request.getParameter("company_name");
                                String contactInfo = request.getParameter("contact_info");

                                try (PreparedStatement clientStmt = conn.prepareStatement(clientSql)) {
                                    clientStmt.setInt(1, userId);
                                    clientStmt.setString(2, companyName);
                                    clientStmt.setString(3, contactInfo);

                                    // Execute client insert
                                    if (clientStmt.executeUpdate() > 0) {
                                        response.sendRedirect("userDashboard.jsp");
                                    } else {
                                        displayError(response, "Client signup failed. Please try again.");
                                    }
                                }
                            } else if ("freelancer".equalsIgnoreCase(role)) {
                                String skills = request.getParameter("skills");
                                String experienceStr = request.getParameter("experience");
                                String portfolio = request.getParameter("portfolio");

                                try (PreparedStatement freelancerStmt = conn.prepareStatement(freelancerSql)) {
                                    freelancerStmt.setInt(1, userId);
                                    freelancerStmt.setString(2, skills);
                                    freelancerStmt.setInt(3, Integer.parseInt(experienceStr));
                                    freelancerStmt.setString(4, portfolio);

                                    // Execute freelancer insert
                                    if (freelancerStmt.executeUpdate() > 0) {
                                        response.sendRedirect("freelancer_dashboard.jsp");
                                    } else {
                                        displayError(response, "Freelancer signup failed. Please try again.");
                                    }
                                }
                            } else if ("admin".equalsIgnoreCase(role)) {
                                response.sendRedirect("admin_dashboard.jsp");
                            } else {
                                displayError(response, "Invalid role selected.");
                            }
                        } else {
                            displayError(response, "User creation failed. Please try again.");
                        }
                    }
                } else {
                    displayError(response, "User signup failed. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Log exception for debugging
            displayError(response, "Database error: " + e.getMessage());
        }
    }

    private void displayError(HttpServletResponse response, String errorMessage) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body><h3>Error: " + errorMessage + "</h3></body></html>");
    }
}
