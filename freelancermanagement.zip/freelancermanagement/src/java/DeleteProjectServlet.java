import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/delete_project")
public class DeleteProjectServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int projectId = Integer.parseInt(request.getParameter("project_id"));
        
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/freelancer_sys", "root", "Sow@2005#18");

            // Delete the project from the database
            String sql = "DELETE FROM projects WHERE project_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, projectId);
            pstmt.executeUpdate();

            // Redirect to manage projects after successful deletion
            response.sendRedirect("manage_projects.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error deleting project: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (Exception e) { e.printStackTrace(); }
        }
    }
}
