import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/upload_portfolio")
@MultipartConfig
public class UploadPortfolioServlet extends HttpServlet {
    private static final String SAVE_DIR = "uploads";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        // Database credentials
        String dbURL = "jdbc:mysql://localhost:3306/freelancer_sys";
        String dbUser = "root";
        String dbPass = "Sow@2005#18";

        // Get freelancer ID and project ID from the request parameters
        String freelancerIdParam = request.getParameter("freelancer_id");
        String projectIdParam = request.getParameter("project_id");

        // Validate freelancer ID and project ID
        if (freelancerIdParam == null || projectIdParam == null) {
            response.getWriter().println("Error: Freelancer ID or Project ID not found. Please log in again.");
            return;
        }

        int freelancerId;
        int projectId;

        try {
            freelancerId = Integer.parseInt(freelancerIdParam);
            projectId = Integer.parseInt(projectIdParam);
        } catch (NumberFormatException e) {
            response.getWriter().println("Error: Invalid Freelancer ID or Project ID.");
            return;
        }

        String title = request.getParameter("title");
        String description = request.getParameter("description");

        // Validate title and description
        if (title == null || title.isEmpty() || description == null || description.isEmpty()) {
            response.getWriter().println("Error: Title and Description are required.");
            return;
        }

        // Get the upload directory
        String appPath = request.getServletContext().getRealPath("");
        String savePath = appPath + File.separator + SAVE_DIR;
        File fileSaveDir = new File(savePath);
        if (!fileSaveDir.exists()) {
            fileSaveDir.mkdir();
        }

        String filePath = null;
        boolean fileUploaded = false;

        // Get parts from the request
        for (Part part : request.getParts()) {
            if (part.getSubmittedFileName() != null && !part.getSubmittedFileName().isEmpty()) {
                String fileName = Paths.get(part.getSubmittedFileName()).getFileName().toString();

                if (fileName != null && !fileName.isEmpty()) {
                    String uniqueFileName = System.currentTimeMillis() + "_" + fileName;
                    filePath = SAVE_DIR + File.separator + uniqueFileName; // Store relative path

                    try {
                        part.write(savePath + File.separator + uniqueFileName);
                        fileUploaded = true;
                    } catch (IOException e) {
                        response.getWriter().println("File upload failed: " + e.getMessage());
                        return;
                    }
                }
            }
        }

        if (!fileUploaded) {
            response.getWriter().println("Error: No file was selected for upload.");
            return;
        }

        // Save the portfolio data into the database
        try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass)) {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String sql = "INSERT INTO portfolio (freelancer_id, project_id, title, file_path, description) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setInt(1, freelancerId);
            statement.setInt(2, projectId);
            statement.setString(3, title);
            statement.setString(4, filePath); // Use the relative file path
            statement.setString(5, description);

            int row = statement.executeUpdate();
            if (row > 0) {
                response.getWriter().println("Portfolio uploaded successfully.");
            } else {
                response.getWriter().println("Error: Portfolio upload failed.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Database error: " + e.getMessage());
        }
    }
}
