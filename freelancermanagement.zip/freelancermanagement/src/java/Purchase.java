package com.example.freelancer;

import javax.servlet.http.HttpServlet;

public class PurchasesServlet extends HttpServlet {
    public static class Purchase {
        private String clientName;
        private String projectName;
        private String purchaseDate; // Consider using Date type for better handling
        private double amount;

        // Constructors, getters, and setters
        public Purchase(String clientName, String projectName, String purchaseDate, double amount) {
            this.clientName = clientName;
            this.projectName = projectName;
            this.purchaseDate = purchaseDate;
            this.amount = amount;
        }

        public String getClientName() {
            return clientName;
        }

        public String getProjectName() {
            return projectName;
        }

        public String getPurchaseDate() {
            return purchaseDate;
        }

        public double getAmount() {
            return amount;
        }
    }

    // Servlet methods (doGet, doPost, etc.) go here
}
