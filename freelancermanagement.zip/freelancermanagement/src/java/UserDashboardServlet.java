package com.yourproject.servlets;

import com.yourproject.models.Project;
import com.yourproject.models.Freelancer;
import com.yourproject.models.User;
import com.yourproject.utils.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/UserDashboardServlet")
public class UserDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        
        // Fetch the current logged-in user from session
        User currentUser = (User) session.getAttribute("currentUser");
        
        // If user is not logged in, redirect to the login page
        if (currentUser == null) {
            response.sendRedirect("index.html");
            return;
        }

        // Set user profile details into the request
        request.setAttribute("username", currentUser.getUsername());

        // Fetch all projects and set them in the request
        List<Project> projectList = getProjects();
        request.setAttribute("projects", projectList);

        // Fetch all freelancers and set them in the request
        List<Freelancer> freelancerList = getFreelancers();
        request.setAttribute("freelancers", freelancerList);

        // Forward request to JSP page (userDashboard.jsp)
        request.getRequestDispatcher("userDashboard.jsp").forward(request, response);
    }

    // Method to fetch the list of projects from the database
    private List<Project> getProjects() {
        List<Project> projectList = new ArrayList<>();
        String query = "SELECT * FROM projects"; // Your actual query
        
        // Try-with-resources ensures automatic resource management
        try (Connection connection = DBConnection.getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Project project = new Project();
                project.setProjectId(rs.getInt("project_id"));
                project.setProjectName(rs.getString("project_name"));
                project.setProjectDescription(rs.getString("project_description"));
                project.setProjectAmount(rs.getBigDecimal("project_amount"));
                project.setSkillsRequired(rs.getString("skills_required"));
                
                // Add the project to the list
                projectList.add(project);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return projectList; // Return the list of projects
    }

    // Method to fetch the list of freelancers from the database
    private List<Freelancer> getFreelancers() {
        List<Freelancer> freelancerList = new ArrayList<>();
        String query = "SELECT f.*, u.username FROM freelancers f JOIN users u ON f.user_id = u.id"; // Your query

        // Try-with-resources for database connection
        try (Connection connection = DBConnection.getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Freelancer freelancer = new Freelancer();
                freelancer.setUserId(rs.getInt("user_id"));
                freelancer.setUsername(rs.getString("username"));
                freelancer.setSkills(rs.getString("skills"));
                freelancer.setExperience(rs.getString("experience"));
                freelancer.setPortfolio(rs.getString("portfolio"));
                
                // Add the freelancer to the list
                freelancerList.add(freelancer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return freelancerList; // Return the list of freelancers
    }
}
