import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.yourproject.utils.DBConnection;

@WebServlet("/AddProjectServlet")
public class AddProjectServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form parameters
        String projectName = request.getParameter("projectName");
        String description = request.getParameter("description");
        BigDecimal budget = new BigDecimal(request.getParameter("budget"));
        String deadline = request.getParameter("deadline");

        // Placeholder values for optional fields
        Integer clientId = null; // Set to actual client ID if available
        String requiredSkills = null; // Set if you collect this value from form
        String status = "open"; // Default status value
        Integer freelancerId = null; // Set to actual freelancer ID if available

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Get database connection
            conn = DBConnection.getConnection();

            // SQL query to insert the project details
            String sql = "INSERT INTO projects (client_id, project_name, description, required_skills, budget, deadline, status, freelancer_id) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);

            // Set parameters for the prepared statement
            if (clientId != null) {
                pstmt.setInt(1, clientId);
            } else {
                pstmt.setNull(1, java.sql.Types.INTEGER);
            }
            pstmt.setString(2, projectName);
            pstmt.setString(3, description);
            pstmt.setString(4, requiredSkills); // Assuming `required_skills` can be null
            pstmt.setBigDecimal(5, budget);
            pstmt.setDate(6, Date.valueOf(deadline));
            pstmt.setString(7, status);
            if (freelancerId != null) {
                pstmt.setInt(8, freelancerId);
            } else {
                pstmt.setNull(8, java.sql.Types.INTEGER);
            }

            // Execute the insert operation
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                // Redirect to the dashboard if project added successfully
                response.sendRedirect("freelancer_dashboard.jsp");
            } else {
                // Print error message if no rows were affected
                response.getWriter().write("Failed to add project.");
            }
        } catch (SQLException e) {
            // Handle SQL exceptions
            e.printStackTrace();
            response.getWriter().write("SQL Error: " + e.getMessage());
        } finally {
            // Close resources
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
