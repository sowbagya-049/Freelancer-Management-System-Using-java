import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.annotation.WebServlet;

@WebServlet("/ViewStarredProjectsServlet")
public class ViewStarredProjectsServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/freelancer_sys"; // Update with your DB URL
    private static final String DB_USER = "root"; // Update with your DB username
    private static final String DB_PASSWORD = "Sow@2005#18"; // Update with your DB password

    // Initialize the database connection driver in init (not static)
    @Override
    public void init() throws ServletException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Ensure the MySQL JDBC driver is loaded
        } catch (ClassNotFoundException e) {
            throw new ServletException("MySQL JDBC Driver not found", e);
        }
    }

    // Method to get the database connection
    private Connection getDBConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    // Main GET method to handle requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // HTML start
        out.println("<html><body>");
        out.println("<h1>Starred Projects</h1>");

        // SQL query to retrieve starred projects
        String query = "SELECT * FROM projects WHERE starred = true"; // Adjust table/column as needed

        try (Connection connection = getDBConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            // Display results
            while (resultSet.next()) {
                String projectName = resultSet.getString("project_name"); // Adjust column name as needed
                out.println("<p>" + projectName + "</p>");
            }

        } catch (SQLException e) {
            // Error handling and user-friendly message
            out.println("<p style='color:red;'>Error retrieving projects: " + e.getMessage() + "</p>");
            e.printStackTrace();
        }

        // HTML end
        out.println("</body></html>");
    }

    // Close any resources if necessary in the servlet destroy method
    @Override
    public void destroy() {
        // Optional cleanup code if any resources need to be closed explicitly
    }
}
