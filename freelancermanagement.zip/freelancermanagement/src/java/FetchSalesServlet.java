import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/fetch_sales")
public class FetchSalesServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/freelancer_sys";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Sow@2005#18";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Retrieve freelancer ID from request parameter
        String freelancerIdParam = request.getParameter("freelancer_id");
        if (freelancerIdParam == null || freelancerIdParam.isEmpty()) {
            response.getWriter().println("Error: Freelancer ID is required.");
            return;
        }

        int freelancerId;
        try {
            freelancerId = Integer.parseInt(freelancerIdParam);
        } catch (NumberFormatException e) {
            response.getWriter().println("Error: Invalid Freelancer ID.");
            return;
        }

        List<SalesRecord> salesRecords = new ArrayList<>();
        
        // Database connection and data retrieval
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT * FROM sales WHERE freelancer_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, freelancerId);
            ResultSet rs = stmt.executeQuery();

            // Loop through the result set and populate sales records
            while (rs.next()) {
                int saleId = rs.getInt("sale_id");
                int projectId = rs.getInt("project_id");
                int clientId = rs.getInt("client_id");
                double amount = rs.getDouble("amount");
                Timestamp saleDate = rs.getTimestamp("sale_date");

                // Adding the retrieved data to the salesRecords list
                salesRecords.add(new SalesRecord(saleId, projectId, clientId, freelancerId, amount, saleDate));
            }
        } catch (SQLException e) {
            Logger.getLogger(FetchSalesServlet.class.getName()).log(Level.SEVERE, "Database error", e);
            response.getWriter().println("Database error: " + e.getMessage());
            return;
        }

        // Set sales records as request attribute and forward to viewSoldProject.jsp
        request.setAttribute("salesRecords", salesRecords);
        request.getRequestDispatcher("viewSoldProject.jsp").forward(request, response);
    }
}
