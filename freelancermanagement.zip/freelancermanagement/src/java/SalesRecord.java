import java.sql.Timestamp;

public class SalesRecord {
    private int saleId;
    private int projectId;
    private int clientId;
    private int freelancerId;
    private double amount;
    private Timestamp saleDate;

    public SalesRecord(int saleId, int projectId, int clientId, int freelancerId, double amount, Timestamp saleDate) {
        this.saleId = saleId;
        this.projectId = projectId;
        this.clientId = clientId;
        this.freelancerId = freelancerId;
        this.amount = amount;
        this.saleDate = saleDate;
    }

    public int getSaleId() { return saleId; }
    public int getProjectId() { return projectId; }
    public int getClientId() { return clientId; }
    public int getFreelancerId() { return freelancerId; }
    public double getAmount() { return amount; }
    public Timestamp getSaleDate() { return saleDate; }
}
