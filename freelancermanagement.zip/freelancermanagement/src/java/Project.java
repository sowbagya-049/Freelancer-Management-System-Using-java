package com.yourproject.models;

import java.math.BigDecimal;

public class Project {
    private int projectId;
    private String projectName;
    private String projectDescription;
    private BigDecimal projectAmount;
    private String skillsRequired;

    // Getters and Setters
    public int getProjectId() { return projectId; }
    public void setProjectId(int projectId) { this.projectId = projectId; }

    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }

    public String getProjectDescription() { return projectDescription; }
    public void setProjectDescription(String projectDescription) { this.projectDescription = projectDescription; }

    public BigDecimal getProjectAmount() { return projectAmount; }
    public void setProjectAmount(BigDecimal projectAmount) { this.projectAmount = projectAmount; }

    public String getSkillsRequired() { return skillsRequired; }
    public void setSkillsRequired(String skillsRequired) { this.skillsRequired = skillsRequired; }
}