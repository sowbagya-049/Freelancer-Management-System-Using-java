package com.yourproject.models;

public class User {
    private int id;
    private String username;
    private String role;
    private String name;   // New field for name
    private String email;  // New field for email

    // Default Constructor
    public User() {}

    // Parameterized Constructor
    public User(int id, String username, String role, String name, String email) {
        this.id = id;
        this.username = username;
        this.role = role;
        this.name = name;
        this.email = email;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getName() {      // New getter for name
        return name;
    }

    public void setName(String name) { // New setter for name
        this.name = name;
    }

    public String getEmail() {     // New getter for email
        return email;
    }

    public void setEmail(String email) { // New setter for email
        this.email = email;
    }
}
