import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/edit_project")
public class EditProjectServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        int projectId = Integer.parseInt(request.getParameter("project_id"));
        String projectName = request.getParameter("project_name");
        String description = request.getParameter("description");
        String requiredSkills = request.getParameter("required_skills");
        double budget = Double.parseDouble(request.getParameter("budget"));
        String deadline = request.getParameter("deadline");

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/freelancer_sys", "root", "Sow@2005#18");

            // SQL statement to update the project
            String sql = "UPDATE projects SET project_name = ?, description = ?, required_skills = ?, budget = ?, deadline = ? WHERE project_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, projectName);
            pstmt.setString(2, description);
            pstmt.setString(3, requiredSkills);
            pstmt.setDouble(4, budget);
            pstmt.setString(5, deadline);
            pstmt.setInt(6, projectId);

            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated > 0) {
                response.sendRedirect("projects.jsp?message=Project updated successfully.");
            } else {
                response.sendRedirect("projects.jsp?error=Project not found.");
            }
        } catch (ClassNotFoundException e) {
            response.sendRedirect("projects.jsp?error=Database driver not found: " + e.getMessage());
        } catch (SQLException e) {
            response.sendRedirect("projects.jsp?error=SQL error: " + e.getMessage());
        } catch (Exception e) {
            response.sendRedirect("projects.jsp?error=Unexpected error: " + e.getMessage());
        } finally {
            // Ensure all resources are closed
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}
