

import com.yourproject.models.Portfolio;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/DeletePortfolioServlet")
public class DeletePortfolioServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/freelancer_sys";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Sow@2005#18";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int portfolioId = Integer.parseInt(request.getParameter("portfolioId"));
        
        // Delete the portfolio
        deletePortfolioFromDatabase(portfolioId);
        
        // Fetch updated portfolio list
        List<Portfolio> portfolios = null;
        try {
            portfolios = getPortfoliosFromDatabase();
        } catch (SQLException ex) {
            Logger.getLogger(DeletePortfolioServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        request.setAttribute("portfolio", portfolios);
        
        // Forward to JSP page
        request.getRequestDispatcher("upload_portfolio.jsp").forward(request, response);
    }
    
    private void deletePortfolioFromDatabase(int portfolioId) throws SQLException {
        String deleteSQL = "DELETE FROM portfolios WHERE portfolio_id = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL)) {
             
            preparedStatement.setInt(1, portfolioId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions (log or notify the user)
        }
    }

    private List<Portfolio> getPortfoliosFromDatabase() throws SQLException {
        List<Portfolio> portfolios = new ArrayList<>();
        String querySQL = "SELECT * FROM portfolio";
        
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = (PreparedStatement) connection.prepareStatement(querySQL);
             ResultSet resultSet = preparedStatement.executeQuery()) {
             
            while (resultSet.next()) {
                Portfolio portfolio = new Portfolio();
                portfolio.setId(resultSet.getInt("portfolio_id"));
                portfolio.setFreelancerId(resultSet.getInt("freelancer_id"));
                portfolio.setProjectId(resultSet.getInt("project_id"));
                portfolio.setTitle(resultSet.getString("title"));
                portfolio.setFilePath(resultSet.getString("file_path"));
                portfolio.setDescription(resultSet.getString("description"));
                
                portfolios.add(portfolio);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exceptions
        }
        
        return portfolios;
    }
}
