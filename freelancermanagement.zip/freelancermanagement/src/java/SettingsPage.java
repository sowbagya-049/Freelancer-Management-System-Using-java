import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SettingsPage extends JFrame {
    private JTextField nameField;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JComboBox<String> notificationsComboBox;
    private JLabel messageLabel;

    public SettingsPage() {
        setTitle("Settings");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 5, 10);
        add(new JLabel("Name:"), gbc);
        
        nameField = new JTextField();
        gbc.gridx = 1;
        add(nameField, gbc);
        
        // Email
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("Email:"), gbc);
        
        emailField = new JTextField();
        gbc.gridx = 1;
        add(emailField, gbc);
        
        // New Password
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("New Password:"), gbc);
        
        passwordField = new JPasswordField();
        gbc.gridx = 1;
        add(passwordField, gbc);
        
        // Notification Preferences
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(new JLabel("Notification Preferences:"), gbc);
        
        notificationsComboBox = new JComboBox<>(new String[]{"All Notifications", "Email Only", "No Notifications"});
        gbc.gridx = 1;
        add(notificationsComboBox, gbc);
        
        // Message Label
        messageLabel = new JLabel("");
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.gridy = 4;
        add(messageLabel, gbc);
        
        // Save Changes Button
        JButton saveButton = new JButton("Save Changes");
        saveButton.addActionListener(new SaveButtonListener());
        gbc.gridx = 0;
        gbc.gridy = 5;
        add(saveButton, gbc);
        
        // Cancel Button
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> System.exit(0)); // Exit application
        gbc.gridx = 1;
        add(cancelButton, gbc);
        
        // Delete Account Button
        JButton deleteButton = new JButton("Delete Account");
        deleteButton.addActionListener(new DeleteButtonListener());
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.gridy = 6;
        add(deleteButton, gbc);
        
        setVisible(true);
    }

    private class SaveButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name = nameField.getText();
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());
            String notifications = (String) notificationsComboBox.getSelectedItem();

            // Database connection details
            String dbURL = "jdbc:mysql://localhost:3306/freelancer_sys";
            String dbUser = "root";
            String dbPass = "Sow@2005#18";

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
                String sql = "UPDATE users SET name=?, password=?, notifications=? WHERE email=?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, name);
                stmt.setString(2, password); // Consider hashing this password!
                stmt.setString(3, notifications);
                stmt.setString(4, email);

                int rowsUpdated = stmt.executeUpdate();
                if (rowsUpdated > 0) {
                    messageLabel.setText("Updated successfully!");
                    messageLabel.setForeground(Color.GREEN);
                } else {
                    messageLabel.setText("Update failed!");
                    messageLabel.setForeground(Color.RED);
                }
                conn.close();
            } catch (SQLException ex) {
                messageLabel.setText("Error executing SQL: " + ex.getMessage());
                messageLabel.setForeground(Color.RED);
            } catch (Exception ex) {
                messageLabel.setText("An error occurred: " + ex.getMessage());
                messageLabel.setForeground(Color.RED);
            }
        }
    }

    private class DeleteButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete your account? This action cannot be undone.", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                // Add your deletion logic here
                JOptionPane.showMessageDialog(null, "Account deleted successfully!"); // Placeholder action
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SettingsPage::new);
    }
}
