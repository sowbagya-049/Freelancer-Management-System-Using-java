package com.yourproject.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    
    private static final String URL = "jdbc:mysql://localhost:3306/freelancer_sys"; // Your DB URL
    private static final String USERNAME = "root"; // Your DB username
    private static final String PASSWORD = "Sow@2005#18"; // Your DB password

    public static Connection getConnection() {
        Connection connection = null;
        try {
            System.out.println("Loading MySQL Driver...");
            Class.forName("com.mysql.cj.jdbc.Driver"); // Load MySQL JDBC Driver
            System.out.println("Driver loaded. Trying to connect...");
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Connection established.");
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found. Include it in your library path.");
            e.printStackTrace(); // Print the full stack trace for debugging
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage()); // Include the exception message
            e.printStackTrace(); // Print the stack trace to find the root cause
        }
        return connection;
    }
}
