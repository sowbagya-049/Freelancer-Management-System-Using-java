public interface DatabaseConfig {
    String DB_URL = "jdbc:mysql://localhost:3306/freelancer_sys"; // Change to your DB URL
    String DB_USER = "root"; // Change to your DB username
    String DB_PASSWORD = "Sow@2005#18"; // Change to your DB password
}
