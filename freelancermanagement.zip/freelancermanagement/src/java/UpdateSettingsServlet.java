import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateSettingsServlet")
public class UpdateSettingsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String projectName = request.getParameter("project-name");
        String notifications = request.getParameter("notifications");

        // Database connection parameters
        String jdbcURL = "jdbc:mysql://localhost:3306/freelancer_sys"; // Change to your DB URL
        String dbUser = "root"; // Change to your DB username
        String dbPassword = "Sow@2005#18"; // Change to your DB password

        Connection conn = null;
        PreparedStatement stmt = null;
        PrintWriter out = response.getWriter();

        try {
            // Load the MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // SQL Update Query
            String sql = "UPDATE users SET name=?, email=?, password=?, project_name=?, notifications=? WHERE email=?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, password); // It's a good practice to hash passwords
            stmt.setString(4, projectName);
            stmt.setString(5, notifications);
            stmt.setString(6, email); // Use the current user's email to find the record to update

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                out.println("<html><body><h2>Settings Updated Successfully!</h2>");
                out.println("<a href='profile.jsp'>Go Back to Profile</a></body></html>");
            } else {
                out.println("<html><body><h2>Error updating settings. Please try again.</h2>");
                out.println("<a href='settingc.jsp'>Go Back to Settings</a></body></html>");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            out.println("<h2>Error loading database driver: " + e.getMessage() + "</h2>");
        } catch (SQLException e) {
            e.printStackTrace();
            out.println("<h2>Error executing SQL: " + e.getMessage() + "</h2>");
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
