// Function to toggle between different dashboard sections
function navigateTo(sectionId) {
    // Hide all sections
    const sections = document.querySelectorAll('.page-section');
    sections.forEach(section => section.classList.remove('active'));

    // Show the selected section
    document.getElementById(sectionId).classList.add('active');
}

// Dummy function for search functionality
function searchProjects() {
    const searchTerm = document.getElementById('searchField').value;
    // Implement AJAX call to fetch matching projects
    // Display results dynamically in the searchResults div
    document.getElementById('searchResults').innerHTML = `Searching for projects with: ${searchTerm}`;
}

// Dummy function for file uploads
function uploadFile() {
    const fileInput = document.getElementById('uploadFile');
    const fileName = fileInput.value.split('\\').pop();
    alert(`Uploading file: ${fileName}`);
}

// Dummy function for sending a message
function sendMessage() {
    const message = document.getElementById('messageInput').value;
    if (message) {
        const messageList = document.getElementById('messageList');
        const newMessage = document.createElement('div');
        newMessage.innerText = `You: ${message}`;
        messageList.appendChild(newMessage);
        document.getElementById('messageInput').value = '';  // Clear input
    }
}
