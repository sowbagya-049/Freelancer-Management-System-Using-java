// Sample data to simulate existing projects uploaded by freelancers
const projects = [
    {
        name: "E-commerce Website Development",
        cost: "$5000",
        software: "React, Node.js",
        timespan: "6 months",
        freelancer: "John Doe",
        contact: "john.doe@example.com"
    },
    {
        name: "Mobile App Design",
        cost: "$3000",
        software: "Figma, Adobe XD",
        timespan: "4 months",
        freelancer: "Jane Smith",
        contact: "jane.smith@example.com"
    },
    {
        name: "Database Optimization",
        cost: "$2000",
        software: "MySQL, MongoDB",
        timespan: "3 months",
        freelancer: "Mike Brown",
        contact: "mike.brown@example.com"
    },
    {
        name: "Social Media Marketing",
        cost: "$1500",
        software: "Hootsuite, Canva",
        timespan: "2 months",
        freelancer: "Lisa Green",
        contact: "lisa.green@example.com"
    },
    {
        name: "Full-stack Web Development",
        cost: "$7000",
        software: "JavaScript, Python, AWS",
        timespan: "8 months",
        freelancer: "Chris Evans",
        contact: "chris.evans@example.com"
    }
];

// Function to dynamically render projects
function renderProjects(projectArray) {
    const projectList = document.getElementById('projectList');
    projectList.innerHTML = '';  // Clear any existing project data

    projectArray.forEach(project => {
        const projectCard = document.createElement('div');
        projectCard.className = 'project-card';

        projectCard.innerHTML = `
            <h3>${project.name}</h3>
            <p><strong>Cost:</strong> ${project.cost}</p>
            <p><strong>Software Used:</strong> ${project.software}</p>
            <p><strong>Timespan:</strong> ${project.timespan}</p>
            <p><strong>Freelancer:</strong> ${project.freelancer} | <a href="mailto:${project.contact}">${project.contact}</a></p>
        `;

        projectList.appendChild(projectCard);
    });
}

// Initial rendering of all projects
renderProjects(projects);

// Filter projects based on user search input
function filterProjects() {
    const searchQuery = document.getElementById('searchField').value.toLowerCase();

    const filteredProjects = projects.filter(project => 
        project.name.toLowerCase().includes(searchQuery)
    );

    renderProjects(filteredProjects);
}