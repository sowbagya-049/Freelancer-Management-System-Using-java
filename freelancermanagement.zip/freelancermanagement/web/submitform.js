/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/javascript.js to edit this template
 */


async function submitForm(event) {
    event.preventDefault(); // Prevent default form submission

    const formData = new FormData(document.getElementById('starProjectForm'));

    try {
        const response = await fetch('StarProjectServlet', {
            method: 'POST',
            body: formData
        });
        const result = await response.text();
        alert(result); // Show success or error message

        // Fetch the starred projects after successfully adding one
        fetchStarredProjects();

    } catch (error) {
        console.error('Error:', error);
        alert('There was an error submitting the form.');
    }
}
