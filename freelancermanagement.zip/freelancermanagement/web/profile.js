// Preview uploaded profile picture before saving
function previewImage(event) {
    const reader = new FileReader();
    reader.onload = function(){
        const output = document.getElementById('userImage');
        output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
}

// Simulate profile picture upload
function uploadProfilePic() {
    alert("Profile picture updated successfully!");
}

// Toggle view profile
function viewProfile() {
    document.getElementById('editProfileForm').classList.add('hidden');
    alert("Viewing Profile: \n\n" + getProfileDetails());
}

// Toggle edit profile form
function editProfile() {
    document.getElementById('editProfileForm').classList.remove('hidden');
}

// Update profile information
function updateProfile() {
    alert("Profile updated successfully!");
}

// Save the edited profile details
function saveProfile() {
    const name = document.getElementById('editName').value;
    const email = document.getElementById('editEmail').value;
    const contactNumber = document.getElementById('editContactNumber').value;
    const linkedin = document.getElementById('editLinkedIn').value;
    const bio = document.getElementById('editBio').value;

    document.getElementById('userName').textContent = name;
    document.getElementById('email').textContent = email;
    document.getElementById('contactNumber').textContent = contactNumber;
    document.getElementById('linkedinUrl').href = linkedin;
    document.getElementById('linkedinUrl').textContent = linkedin;
    document.getElementById('userBio').textContent = bio;

    alert("Profile saved successfully!");
}

// Get profile details for viewing
function getProfileDetails() {
    return `
        Name: ${document.getElementById('userName').textContent}
        Email: ${document.getElementById('email').textContent}
        Contact: ${document.getElementById('contactNumber').textContent}
        LinkedIn: ${document.getElementById('linkedinUrl').textContent}
        Bio: ${document.getElementById('userBio').textContent}
    `;
}